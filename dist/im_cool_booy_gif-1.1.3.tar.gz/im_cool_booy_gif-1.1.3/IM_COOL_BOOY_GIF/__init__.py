# __init__.py

from .im_cool_booy_gif import main
