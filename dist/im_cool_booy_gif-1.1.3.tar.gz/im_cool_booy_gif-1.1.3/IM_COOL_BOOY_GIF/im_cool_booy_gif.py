# im_cool_booy_gif.py

def main():
    print("GIF creation started...")
    print("1️⃣ Create a folder named 'Download' in your sdcard.")
    print("2️⃣ Place the photos you want to include in the GIF into that folder.")
    print("3️⃣ Run the command 'IM-COOL-BOOY-GIF'.")
